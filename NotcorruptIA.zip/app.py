
from flask import Flask, request, jsonify, render_template_string
import pickle
import os
import joblib

app = Flask(__name__)

MODEL_PATH = os.getenv("MODEL_PATH", "modelo_malware.pkl")
VECTORIZER_PATH = os.getenv("VECTORIZER_PATH", "vectorizer.pkl")

modelo = joblib.load(MODEL_PATH)
vectorizer = joblib.load(VECTORIZER_PATH)

@app.route('/')
def home():
    return render_template_string(open('frontend.html').read())

@app.route('/analizar', methods=['POST'])
def analizar():
    contenido = request.json.get('contenido', '')
    vector = vectorizer.transform([contenido])
    resultado = modelo.predict(vector)[0]
    return jsonify({'resultado': resultado})
