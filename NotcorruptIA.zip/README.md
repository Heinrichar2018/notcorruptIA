# NotcorruptIA

NotcorruptIA es una aplicación web que utiliza Inteligencia Artificial para detectar si el contenido de un archivo podría ser malicioso. Ideal para auditar código generado por otras IAs o scripts sospechosos.

## Características

- Interfaz sencilla y web para subir y analizar archivos
- Motor IA entrenado con scikit-learn
- Detección de patrones potencialmente maliciosos
- Preparado para despliegue en Render

## Instalación

```bash
pip install -r requirements.txt
python app.py
```

## Uso

Abre la app en tu navegador y pegá el contenido a analizar.

## Despliegue en Render

- **Comando de compilación**: `pip install -r requirements.txt`
- **Comando de inicio**: `gunicorn app:app`
- **Directorio raíz**: (dejalo vacío)
- **Variables de entorno opcionales**:
  - `MODEL_PATH=modelo_malware.pkl`
  - `VECTORIZER_PATH=vectorizer.pkl`
