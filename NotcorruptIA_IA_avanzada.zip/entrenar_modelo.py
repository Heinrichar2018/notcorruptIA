import os
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier

def cargar_datos(directorio, etiqueta):
    textos = []
    etiquetas = []
    for nombre in os.listdir(directorio):
        ruta = os.path.join(directorio, nombre)
        if os.path.isfile(ruta):
            with open(ruta, "r", encoding="utf-8", errors="ignore") as f:
                textos.append(f.read())
                etiquetas.append(etiqueta)
    return textos, etiquetas

seguros_txt, etiquetas_seguros = cargar_datos("datos/seguros", "seguro")
maliciosos_txt, etiquetas_maliciosos = cargar_datos("datos/maliciosos", "malicioso")

X = seguros_txt + maliciosos_txt
y = etiquetas_seguros + etiquetas_maliciosos

vectorizer = TfidfVectorizer(analyzer="char", ngram_range=(3, 6))
X_vect = vectorizer.fit_transform(X)

modelo = RandomForestClassifier(n_estimators=100)
modelo.fit(X_vect, y)

joblib.dump(modelo, "modelo_malware.pkl")
joblib.dump(vectorizer, "vectorizer.pkl")