import os
os.remove('archivo.txt')
exec('print(123)')