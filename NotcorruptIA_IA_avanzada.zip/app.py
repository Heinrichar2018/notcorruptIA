from flask import Flask, request, jsonify
import joblib

app = Flask(__name__)
modelo = joblib.load("modelo_malware.pkl")
vectorizer = joblib.load("vectorizer.pkl")

@app.route("/analizar", methods=["POST"])
def analizar():
    archivo = request.files["archivo"]
    texto = archivo.read().decode("utf-8", errors="ignore")
    vector = vectorizer.transform([texto])
    prediccion = modelo.predict(vector)[0]
    return jsonify({"resultado": prediccion})

if __name__ == "__main__":
    app.run(debug=True)